bs = input("Basic Salary: ");
da = input("DA: ");
hra = input("HRA: ");
ma= input("MA: ");
pf= input ("PF: ");
it = input("IT: ");

sal= bs+da+hra+ma-pf-it

fprintf("Net Salary: %d \n",sal)
