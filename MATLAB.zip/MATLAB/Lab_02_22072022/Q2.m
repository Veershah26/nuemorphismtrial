r = input("Radius: ")
A = pi*(r^2)
C = 2*pi*r
fprintf("Are: %d\n",A)
fprintf("Circumference: %d\n",C)

