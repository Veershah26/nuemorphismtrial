l = input("Length: ")
b = input("Breadth: ")
h = input("Height: ")

Volume=l*b*h
Surface_Area=2*((l*b)+(b*h)+(l*h))

fprintf("Volumne: %d\n",Volume)
fprintf("Surface Area: %d\n",Surface_Area)