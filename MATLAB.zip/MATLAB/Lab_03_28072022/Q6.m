str =  input("Enter String: " , 's');
word_list = strsplit(str);
count = length(word_list);

if isempty(str) == 0
  for i = 1:length(word_list)
    if (~isempty(regexp(word_list{i},'^\d+$'))) == 1
    elseif (~isempty(regexp(word_list{i}(1),'^\d+$'))) == 1
      count = count-1;
    end
    if (isempty(regexp(word_list{i},'^\w+$'))) == 1
      count = count-1;
    endif
  end
else
  count = 0;
endif
fprintf("Total Word Count = %d \n",count)

