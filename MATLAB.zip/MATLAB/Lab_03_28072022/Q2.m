str =  input("Enter String: " , 's');
word_list = strsplit(str);
if isempty(str) == 0
  for i = 1:length(word_list)
    if isupper(word_list{i}(1))
      fprintf("%s Starts With Capital Letter\n",word_list{i})
    else
      fprintf("%s Does Not Start With Capital Letters\n",word_list{i})
    endif
  end
else
  fprintf("Empty String\n")
endif

