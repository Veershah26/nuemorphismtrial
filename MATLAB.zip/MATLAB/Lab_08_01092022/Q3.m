sq=input("Enter the size of square matrix: ")
n=sq*sq
a=0;
a1=1;
a2=a+a1;
pos=1;
fibo=zeros(1,n);
if(n==0)
  fibo(pos)=a
  
else
  fibo(pos)=a;
  pos+=1;
  fibo(pos)=a1;
  pos+=1;
  for i=3:n
    fibo(pos)=a2;
    pos+=1;
    a=a1;
    a1=a2;
    a2=a+a1;
  endfor
end
fprintf("\n");
fibo=reshape(fibo,sq,sq).';
disp(fibo);

