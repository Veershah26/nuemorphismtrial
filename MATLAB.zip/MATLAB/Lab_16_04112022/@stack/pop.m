function po = pop(obj)
  if(obj.a(end)==-1 && length(obj.a)==1)
    disp("stack is empty");   
  else
  obj.a(end)=[];
  disp("stack after pop");
  disp(obj.a); 
  endif
  po=obj;
endfunction