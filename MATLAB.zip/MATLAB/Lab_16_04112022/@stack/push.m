function pu = push(obj,val)
  obj.a=[obj.a val];
  disp("stack after push");
  disp(obj.a);
  pu=obj;
endfunction