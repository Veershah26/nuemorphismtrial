function obj = StudentClass(name,rollno,marks1,marks2,marks3)
  obj.name=name;
  obj.rollno=rollno;
  obj.marks1=marks1;
  obj.marks2=marks2;
  obj.marks3=marks3;
  obj=class(obj,'StudentClass');
  %disp(obj.marks1);
end

