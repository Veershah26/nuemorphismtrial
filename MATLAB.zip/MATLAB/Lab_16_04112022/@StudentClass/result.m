function res = result(obj,marks)
  res = (obj.marks1+obj.marks2+obj.marks3)/3;
  
  %fieldnames(obj)
  %obj.marks1
  %res = 1;
end