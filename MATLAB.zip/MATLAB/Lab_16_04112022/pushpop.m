clear all;
close all;

val = input("push 1:");
val1 = input("push 2:");

p=stack([-1]);
p=push(p,val);
p=push(p,val1);

p=pop(p);
p=pop(p);
p=pop(p);