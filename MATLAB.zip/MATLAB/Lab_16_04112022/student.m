clear all;
close all;
name = input("Enter the Name of Student :" , 's');
s = StudentClass("pavan",1,10,10,10);
r = s
a = result(r)