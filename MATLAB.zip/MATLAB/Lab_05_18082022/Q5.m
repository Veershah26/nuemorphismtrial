str = 'six sides of a hexagon';
[start,ending,substr] = regexp(str, 's(\w*)s')
