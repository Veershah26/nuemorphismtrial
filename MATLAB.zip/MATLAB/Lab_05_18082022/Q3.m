str = {'Madrid, Spain' 'Romeo and Juliet' 'MATLAB is great'};
s = regexp(str(1),{'[A-Z]' '\s'});
disp("Capital letters, '[A-Z]', were found at these str indices: ");
s{:,1}
disp("Space characters, '\s', were found at these str indices: ");
s{:,2}
