fprintf("Current date and time: ");
disp(datestr(now));
fprintf("Current year: ");
disp(datestr(now,10));
fprintf("Month of year: ");
disp(datestr(now,3));
fprintf("Week number of the year: ");
disp(weeknum(datenum(clock)));
fprintf("Weekday of the week: ");
disp(weekday(now));
%disp(datestr(now,8));
fprintf("Day of year: ");
disp(day(now,'dayofyear'));
%disp(day(datetime(clock),'dayofyear'));
fprintf("Day of the month: ");
disp(datestr(now,7));
fprintf("Day of week: ");
disp(datestr(now,8));

