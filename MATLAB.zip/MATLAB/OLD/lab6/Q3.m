function f = Q3(n)
  if (n == 1)
    f = 1;
    fprintf("%d",f);
  elseif (n == 2)
    f = 2;
  else
      f1 = 2;
      f2 = 1;
      for i = 3 : n
        f = f1 + f2;
        f2 = f1;
        f1 = f;
      end
  end
end