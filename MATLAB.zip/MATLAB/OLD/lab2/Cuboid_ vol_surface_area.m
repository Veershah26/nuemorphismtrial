l = input("Input length of cuboid : ")
b = input("Input breadth of cuboid : ")
h = input("Input height of cuboid : ")

Vol=l*b*h
Surface_A=2*((l*b)+(b*h)+(l*h))

fprintf("Volumne of cuboid = %d\n",Vol)
fprintf("Surface Area of cuboid = %d\n",Surface_A)