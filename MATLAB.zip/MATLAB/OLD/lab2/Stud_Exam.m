s1 = input("Marks in Subject 1 out of 100 : ")
s2 = input("Marks in Subject 2 out of 100 : ")
s3 = input("Marks in Subject 3 out of 100 : ")

Total = s1+s2+s3
perc = (Total*100)/300

fprintf("Total Marks: %d\n",Total)
fprintf("Percentage: %d %% \n",perc)
