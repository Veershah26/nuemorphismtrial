bs = input("Enter basic salary :");
da = input("Daily allowance :");
hra = input("House rent allowance :");
ma= input("Medical assistant:");
pf= input ("Provisional fund:");
it = input("Income tax:");

sal= bs+da+hra+ma-pf-it

fprintf("Net Salary: %d \n",sal)
