r = input("Input Radius of circle : ")
A = pi*(r^2)
C = 2*pi*r
fprintf("Area of Circle with Radius: %d is = %d\n",r,A)
fprintf("Circumference of Circle with Radius: %d is = %d\n",r,C)

