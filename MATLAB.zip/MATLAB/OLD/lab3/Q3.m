str =  input("Enter the string :" , 's');
count = length(erase(str,' '));
fprintf("Total Letter Count = %d \n",count)

