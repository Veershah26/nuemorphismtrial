str =  input("Enter the string :" , 's');
word_list = strsplit(str);

if isempty(str) == 0
  for i = 1:length(word_list)
    if isupper(word_list{i}(1))
      fprintf("%s starts with capital letter\n",word_list{i})
    else
      fprintf("%s does not start with capital letter\n",word_list{i})
    endif
  end
else
  fprintf("The String is empty\n")
endif

