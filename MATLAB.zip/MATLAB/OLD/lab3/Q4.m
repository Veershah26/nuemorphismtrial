str =  input("Enter the string :" , 's');
find_letter =  input("Enter the letter :" , 's');
count=length(strfind(str,find_letter));
fprintf("%d time/s letter %c occoured \n",count,find_letter)

