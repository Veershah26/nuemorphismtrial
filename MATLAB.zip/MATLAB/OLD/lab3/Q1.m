str =  input("Enter the string :" , 's');
word_list = strsplit(str);
if isempty(str) == 0
  if isupper(word_list{1}(1))
    fprintf("%s starts with capital letter\n",word_list{1})
  else
    fprintf("%s does not start with capital letter\n",word_list{1})
  endif
else
  fprintf("The String is empty\n")
endif

