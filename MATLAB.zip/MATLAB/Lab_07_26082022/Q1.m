str =  input("Enter the string :" , 's');
fprintf("Number of Vowels: ");
disp(length(regexp(str, '[aeiou]')));
