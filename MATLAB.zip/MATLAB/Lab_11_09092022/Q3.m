z =  inline('6*x-4*y+x*y+cos(2*(x-k))','x','y','k');
disp("Value of 6x − 4y + xy + cos2 (x − k) =");
disp(z(1,2,1));
