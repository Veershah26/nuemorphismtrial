phi = (1+sqrt(5))/2
x = pi^phi
y = phi^pi
if (x > y)
  disp("pi^phi is greater")
else
  disp("phi^pi is greater")
endif