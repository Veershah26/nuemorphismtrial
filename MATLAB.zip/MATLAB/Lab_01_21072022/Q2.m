disp('ans 1.2.a \n')
F = 62 
C=5/9*(F-32) 
disp(C)

disp('ans 1.2.b \n')
C = 100 
F=C*9/5+32 
disp(F)