sqr = @(x) x.^2;
sqr(2)