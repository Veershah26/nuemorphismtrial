function Brahmatower(n, A, B, C)
  if (n == 0)
   return 
  end
  Brahmatower(n-1, A, C, B);
  fprintf("Move disk %d from rod %s to rod %s \n",n,A,B);
  Brahmatower(n-1, C, B, A);

end