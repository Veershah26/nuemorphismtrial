function EMI(P,N,R)
  R=R/12/100;
  N=N*12;
  disp(P);
  disp(N);
  disp(R);
  emi=P*R*(((1+R)^N)/(((1+R)^N)-1));
  sprintf('%g',emi)
end
