year=input('Enter A Year: ');
if (rem(year,400)==0 || rem(year,4)==0 && rem(year,100)~=0)
    disp('It Is A Leap Year')
else
    disp('The Year Is Not A Leap Year')
end
