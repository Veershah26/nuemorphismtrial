datestr(datenum(clock),13)
datestr(datenum(clock + 0.00000014),13)
