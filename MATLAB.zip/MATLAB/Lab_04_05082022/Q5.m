fprintf("Yesterday: ");
disp(datestr(datenum(clock) - 1,1));
fprintf("Today: ");
disp(datestr(now,1));
fprintf("Tomorrow: ");
disp(datestr(datenum(clock) + 1,1));
