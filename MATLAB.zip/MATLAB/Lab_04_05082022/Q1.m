fprintf("Current Date & Time: ");
disp(datestr(now));
fprintf("Current Year: ");
disp(datestr(now,10));
fprintf("Month: ");
disp(datestr(now,3));
fprintf("Week Number: ");
disp(weeknum(datenum(clock)));
fprintf("Weekday: ");
disp(weekday(now));
%disp(datestr(now,8));
fprintf("Day Of Year: ");
disp(day(now,'dayofyear'));
%disp(day(datetime(clock),'dayofyear'));
fprintf("Day Of Month: ");
disp(datestr(now,7));
fprintf("Day Of Week: ");
disp(datestr(now,8));

