fprintf("Current time: ");
disp(datestr(now,13));
