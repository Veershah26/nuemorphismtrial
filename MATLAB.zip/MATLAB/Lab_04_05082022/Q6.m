disp("Today : ")
datestr(datenum(clock),8)
disp("next 5 days from today are:");
for i =1:5
  disp(datestr(datenum(clock) + i,8));
end
