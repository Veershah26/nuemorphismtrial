function dp = DatePalindrome(num)
  num = num2str(num);
  num = datestr(num,2);
  fprintf('Your number = %s\nFlipped, it = %s\n', num, fliplr(num));
  if num == fliplr(num)
    disp('Your date is a PALINDROME')
  else
    disp('Your date is NOT A PALINDROME')
  end
end
