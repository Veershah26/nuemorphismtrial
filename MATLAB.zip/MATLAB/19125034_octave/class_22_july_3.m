
function cuboid()

l= input("Enter the length : ");
b=input ("Enter the breadth: ");
h = input ("Enter the height: ");

volume = l.*b.*h;

surface_area = 2.*(l.*b+b.*h+l.*h);

disp([" The volume of the cuboid :",num2str(volume)])
disp([" The surface area of the cuboid :",num2str(surface_area)])

end