
function marks()

m1= input("Enter the marks in subject 1 : ");
m2=input ("Enter the marks in subject 2 : ");
m3= input ("Enter the marks in subject 3: ");

total = m1+m2+m3;
percentage = (total/300).*100

disp([" Total marks in all in subject:",num2str(total)])
disp([" Overall Percentage  :",num2str(percentage)])

end