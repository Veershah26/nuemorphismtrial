data = fopen('marksheet.csv');
A = textscan(data,'%s','Delimiter','\n');
B = A{1,1}
C=B{1,1}

d=B{2,1}


