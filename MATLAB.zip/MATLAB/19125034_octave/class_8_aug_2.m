str = 'PruthviP@gmail.com ';
str_new = regexprep(str,'[^a-zA-Z]','');
disp([" String  :",str_new])