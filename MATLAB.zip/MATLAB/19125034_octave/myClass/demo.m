
clear all;
close all;

a = NovThree;

a.Value = 3;


disp("Value: ")
a.Value

disp("Addition: ")
add(a,4)
disp("Multiplication: ")
multiplyBy(a,3)
disp("Subtraction: ")
sub(a,3)
disp("Division: ")
div(a,3)
