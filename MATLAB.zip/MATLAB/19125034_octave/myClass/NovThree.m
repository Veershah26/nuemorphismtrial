classdef NovThree
   properties
      Value 
   end
   methods
   
      function r = add(obj,n)
         r = [obj.Value]+n;
      end
      
      function r = multiplyBy(obj,n)
         r = [obj.Value]*n;
      end
      
      function r = sub(obj,n)
         r = [obj.Value]-n;
      end
      
       function r = div(obj,n)
         r = [obj.Value]/n;
      end
      
   end
end



