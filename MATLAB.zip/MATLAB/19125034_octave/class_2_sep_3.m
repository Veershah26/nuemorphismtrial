function permutation(n = 5 , r = 3)
 nPr =  gamma(n+1)/(gamma((n-r)+1))
 end