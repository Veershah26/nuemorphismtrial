function combination(n = 11 , r = 7)
 nCr =  gamma(n+1)/(gamma(r+1)*gamma((n-r)+1))
 end