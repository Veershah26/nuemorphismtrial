

function area_circle()
r = input('Enter the radius: ');
area = pi.*r.^2;
circumference = 2.*pi.*r
disp(['Area of circle: ', num2str(area)])
disp(['circumference of circle: ', num2str(circumference)])
end

