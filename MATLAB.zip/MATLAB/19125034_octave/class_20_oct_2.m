A = imread('kid.jpg');



R = A(:,:,1);
G = A(:,:,2); 
B = A(:,:,3);

hist(R)
hist(G)
hist(B)
