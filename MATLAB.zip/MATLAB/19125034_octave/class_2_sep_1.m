x = [1];
for i = 1 : 4
    x = strcat(x,num2str(i));
    s = [blanks(5-i) x];
    disp([s fliplr(s)]);
end


%{x = [];
y=11
for i = 1 : 5
   
    x = strcat(x,num2str(y));
    s = [blanks(5-i) x];
    disp([s fliplr(s)])
    y=11^i;
    
end%}