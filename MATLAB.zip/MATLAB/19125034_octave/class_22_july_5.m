
function salary()

bs = input("Enter basic salary :");
da = input("Daily allowance :");
hra = input("House rent allowance :");
ma= input("Medical assistant:");
pf= input ("Provisional fund:");
it = input("Income tax:");

net_salary= bs+da+hra+ma-pf-it

disp([" Net Salary  :",num2str(net_salary)])

end