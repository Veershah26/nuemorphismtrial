%1.Anonymous Functions
%sqr = @(x) x.^3;
%a = sqr(2)

%2.Local function
%class_8_sep_1([1,2,3,4]) use in cmd to run below code
%{function [avg] = class_8_sep_1(x)
x=[1,2,3,4]
n = length(x);
avg = mymean(x,n);

end

function a = mymean(v,n)
% MYMEAN Example of a local function.

a = sum(v)/n;
end
%}

%3. Nested function
%{function class_8_sep_1
disp('This is the parent function')
nestedfx

   function nestedfx
      disp('This is the nested function')
   end

end 
%}

%4. Private function
function class_8_sep_1
findme

