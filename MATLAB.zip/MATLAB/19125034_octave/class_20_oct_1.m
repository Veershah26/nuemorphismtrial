

prompt = "Enter value between 1-4 ";
x = input(prompt)

rectangle('Position',[2 2 4 4],'FaceColor','R')

if x==1 
  rectangle('Position',[4 4 2 2],'FaceColor','Y')
elseif x==2
  rectangle('Position',[2 4 2 2],'FaceColor','Y')
elseif x==3
  rectangle('Position',[2 2 2 2],'FaceColor','Y')
elseif x==4
  rectangle('Position',[4 2 2 2],'FaceColor','Y')
end 

axis square
axis([0 10 0 10])