
str = input("Enter string :",'s');

disp([" String  :",str])


newStr = regexp(str,'split')