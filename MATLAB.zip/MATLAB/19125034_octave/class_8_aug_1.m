vowel_count = @(s) nnz(ismember(lower(s),'aeiou'));
vowel_count('Pruthvi Patel')
