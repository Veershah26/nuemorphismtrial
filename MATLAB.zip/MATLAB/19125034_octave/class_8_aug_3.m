function check_amstrong_number(input=153)
if isnumeric(input)
    input_num = num2str(input);
else
    error('Input shoud be numberic')
end
amst_num = 0;
for i1 = 1 : length(input_num)
    amst_num = amst_num + str2double(input_num(i1)) ^ length(input_num);
end
if amst_num == input
    disp(['Number ' input_num ' is Amstrong_Number'])
else
    disp(['Number ' input_num ' is NOT a Amstrong_Number'])
end

