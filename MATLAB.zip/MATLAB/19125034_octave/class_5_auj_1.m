
a= datestr(now) % current date and time
b=datestr(3,'mm/dd',now)