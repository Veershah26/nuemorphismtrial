function ambigram(num)
  num=num2str(num)
  h = ["0" "0"; "1" "1"; "6" "9"; "8" "8"; "9" "6"];
  i = 1;
  j = length(num);
  flag = 0;
  while i<=j
    [tf, index] = ismember(h, [num(i) num(j)] , "rows");
    if any(tf)
     
      flag = 1;
    else 
      c = 0;
    end
    i = i+1;
    j = j-1;
  end
  if flag == 1
    disp(["The number is Ambigram"])
  else 
    disp(["The number is not Ambigram"])
  end
end