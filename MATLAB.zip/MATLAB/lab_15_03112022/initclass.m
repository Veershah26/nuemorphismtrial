clear all;
close all;

a = BasicClass;

a.Value = pi;

disp("Value of pi:");
disp(a.Value)

disp("Roundoff value of pi:");
disp(roundOff(a));

disp("Multiply pi*3:");
disp(multiplyBy(a,3));