clear all;
close all;

BA = BankAccount(1234567,500)
getStatement(BA)
withdraw(BA,600)
getStatement(BA)
withdraw(BA,200)
getStatement(BA)
withdraw(BA,100)
disp("Desposit");
deposit(BA,700)
getStatement(BA)