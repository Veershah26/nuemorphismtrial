classdef AccountManager 
  methods (Static)
    function assignStatus(BA)
      if BA.AccountBalance < 0
        if BA.AccountBalance < -200
          BA.AccountStatus = "Closed";
        else
          BA.AccountStatus = "Overdrawn";
        end
      end
    end
    function lh = addAccount(BA)
      lh = addlistener(BA, "Insufficient Funds",@(src,~)AccountManager.assignStatus(src));
    end
  end
end