%input [[a,b];[a,b],[a,b];[a,b]]
function euclidean2(p,q)
  n=length(p);
  m=length(q);
  for i=1:n
    for j=1:m
      D(i,j)=euclidean(p(i,:),q(j,:));
    endfor
  endfor
  D
end

function dist = euclidean(p,q)
  n=length(p);
  eucl=0;
  for i=1:n
    eucl=eucl+(q(i)-p(i))^2;
  endfor
  dist = sqrt(eucl);
end