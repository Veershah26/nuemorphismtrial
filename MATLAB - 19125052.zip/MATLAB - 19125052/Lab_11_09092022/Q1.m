function euclidean(p,q)
  if(length(p)==length(q))
    n=length(p);
    eucl=0;
    for i=1:n
      eucl=eucl+(q(i)-p(i))^2;
    endfor
    fprintf("Euclidean distance = %d\n",sqrt(eucl));
  else
    disp("length of points are not same");
  end
end