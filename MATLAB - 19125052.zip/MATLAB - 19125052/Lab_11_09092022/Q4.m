function inSquare(x,y,p,q,s)

  plot(p,q,'b*')
  rectangle('Position',[p q s s])
  axis square
  axis([p-1 p+s+1 q-1 q+s+1])

  if(((x >= p) && (x <= (x+s))) && (((y >=q) && y <= (q + s))))
    result = true;
    fprintf('The point (%d,%d) is  in the square\n',x,y);
  else
    result = false;
    fprintf('The point(%d,%d) is not in the square\n',x,y);
end
