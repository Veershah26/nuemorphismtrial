disp(csvread('gradesheet.csv'));

data=fopen('gradesheet.csv')

A=textscan(data,"%s",'Delimiter',",")
