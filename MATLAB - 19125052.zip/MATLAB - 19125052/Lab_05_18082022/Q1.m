str =  input("Enter the string :" , 's');
word_list = strsplit(str);
disp(word_list);
