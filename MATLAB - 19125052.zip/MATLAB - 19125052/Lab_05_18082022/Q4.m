str = 'regexp helps you relax';
[start,ending] = regexp(str, '\w*x\w*')
