%str =  input("Enter the string :" , 's');
str = 'bat cat can car coat court cut ct caoueouat';
regexp(str, 'c[aeiou]+t')
