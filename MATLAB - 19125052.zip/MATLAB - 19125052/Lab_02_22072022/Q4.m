s1 = input("Subject 1 Marks: ")
s2 = input("Subject 2 Marks: ")
s3 = input("Subject 3 Marks: ")

Total = s1+s2+s3
perc = (Total*100)/300

fprintf("Total Marks: %d\n",Total)
fprintf("Percentage: %d%% \n",perc)
