clear all;
close all;

a = BasicClass;

a.Value = pi;

disp("Pi:");
disp(a.Value)

disp("Roundoff Pi:");
disp(roundOff(a));

disp("Pi*3:");
disp(multiplyBy(a,3));