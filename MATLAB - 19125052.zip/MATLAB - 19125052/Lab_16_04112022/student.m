clear all;
close all;
name = input("Enter the Name of Student :" , 's');
s = StudentClass("Veer",91,96,82,95);
r = s
a = result(r)