function pu = push(obj,val)
  obj.a=[obj.a val];
  disp("After Push");
  disp(obj.a);
  pu=obj;
endfunction