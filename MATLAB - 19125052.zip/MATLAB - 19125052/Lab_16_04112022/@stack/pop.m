function po = pop(obj)
  if(obj.a(end)==-1 && length(obj.a)==1)
    disp("Empty Stack");   
  else
  obj.a(end)=[];
  disp("After Pop");
  disp(obj.a); 
  endif
  po=obj;
endfunction