function obj = stack(a)
  obj.a=[a];
  obj=class(obj,'stack');
end
