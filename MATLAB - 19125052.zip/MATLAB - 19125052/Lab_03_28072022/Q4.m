str =  input("Enter String: ", 's');
find_letter =  input("Enter Letter: " , 's');
count=length(strfind(str,find_letter));
fprintf("Letter Occoured %d Times\n",count)

