str =  input("Enter String: " , 's');

word_list = strsplit(str);
count = length(word_list);

if isempty(str) == 0
  for i = 1:length(word_list)
    if all(ismember((word_list{i}), '0 1 2 3 4 5 6 7 8 9')) == 1
      elseif ismember((word_list{i}(1)), '0 1 2 3 4 5 6 7 8 9') == 1
        count = count-1;
    end
  end
else
  count = 0;
endif
fprintf("Total Word Count = %d \n",count)

