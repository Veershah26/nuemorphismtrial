str =  input("Enter String: ", 's');
word_list = strsplit(str);
if isempty(str) == 0
  if isupper(word_list{1}(1))
    fprintf("%s Starts With Capital Letter\n",word_list{1})
  else
    fprintf("%s Does Not Start With Capital Letter\n",word_list{1})
  endif
else
  fprintf("Empty String\n")
endif

