str =  input("Enter String: ", 's');
count = length(erase(str,' '));
fprintf("Total Letter Count = %d \n",count)

