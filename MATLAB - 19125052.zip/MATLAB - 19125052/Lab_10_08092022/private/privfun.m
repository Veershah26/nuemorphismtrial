function privfun
% FINDME  An example of a private function.

disp('You found the private function.')
