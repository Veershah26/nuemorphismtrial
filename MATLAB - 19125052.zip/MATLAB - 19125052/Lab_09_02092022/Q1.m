n = 5
for i = (0 : n-1)
  for j = (0 : n-i-2)
    fprintf(" ");
  endfor
  for j = (0:i)
    %disp(abs(i-j));
    fact=factorial(i)/(factorial(j)*factorial(abs(i-j)));
    fprintf("%.f ",fact);
  endfor
  fprintf("\n");
endfor