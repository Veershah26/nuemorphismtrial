fprintf("Current date: ");
disp(datestr(now,1));
fprintf("Current date minus 5 days: ");
disp(datestr(datenum(clock) - 5,1));
