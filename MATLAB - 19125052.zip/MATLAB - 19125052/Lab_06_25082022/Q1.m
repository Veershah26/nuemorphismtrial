function Palindrome(num)
  num=num2str(num);
  fprintf('Your number = %s\nFlipped, it = %s\n', num, fliplr(num));
  if num == fliplr(num)
    disp('Your number is a PALINDROME')
  else
    disp('Your number is NOT A PALINDROME')
  end
end
