function UpperLower(str)
  str =  lower(num2str(str));
  word_list = strsplit(str);
  for i = 1:2:length(word_list)
    word_list{i}=upper(word_list{i});
  end
  for i = 1:length(word_list)
    fprintf("%s ",word_list{i});
  end
  fprintf("\n");
end
