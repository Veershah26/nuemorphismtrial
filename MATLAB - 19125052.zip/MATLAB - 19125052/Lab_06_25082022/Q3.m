function f = Fibonacci(n)
  a=0;
  a1=1;
  a2=a+a1;
  if(n==0)
    fprintf(" %d ",a);
  else
    fprintf(" %d %d",a,a1);
    for i=3:n
      fprintf(" %d ",a2);
      a=a1;
      a1=a2;
      a2=a+a1;
    endfor
  end
  fprintf("\n");
end
