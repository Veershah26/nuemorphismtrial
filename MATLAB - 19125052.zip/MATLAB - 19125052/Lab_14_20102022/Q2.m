I=imread('download.jpg');
R=I(:,:,1);
G=I(:,:,2);
B=I(:,:,3);
hist(R,25,"Facecolor", "r")
hold on
hist(G,25,"Facecolor", "g")
hist(B,25,"Facecolor", "b") 
legend('Red Channel','Green channel','Blue channel');
h = findobj(gca,'Type','patch');
%display(h)

set(h(1),'FaceColor','r','EdgeColor','k');
set(h(2),'FaceColor','g','EdgeColor','k');
set(h(2),'FaceColor','b','EdgeColor','k');