X1=[0 0 1 1];
Y1=[0 1 1 0];
X2=[0 0 -1 -1];
Y2=[0 1 1 0];
X3=[0 0 -1 -1];
Y3=[0 -1 -1 0];
X4=[0 0 1 1];
Y4=[0 -1 -1 0];
grid
hold on

FillArea = input('Enter A Number: ', 's');
switch FillArea
  case '1'
    fill(X1,Y1,'r');
    fill(X2,Y2,'b');
    fill(X3,Y3,'b');
    fill(X4,Y4,'b');
  case '2'
    fill(X1,Y1,'b');
    fill(X2,Y2,'r');
    fill(X3,Y3,'b');
    fill(X4,Y4,'b');
  case '3'
    fill(X1,Y1,'b');
    fill(X2,Y2,'b');
    fill(X3,Y3,'r');
    fill(X4,Y4,'b');
  case '4'
    fill(X1,Y1,'b');
    fill(X2,Y2,'b');
    fill(X3,Y3,'b');
    fill(X4,Y4,'r');
  otherwise
  disp("Invalid Choice");
end