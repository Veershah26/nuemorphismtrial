str =  input("Enter the string :" , 's');
fprintf("Your Entered String: %s ", str);
str_changed = regexprep(str,'[^a-zA-Z]','');
fprintf("\nTransformed String: %s\n", str_changed);