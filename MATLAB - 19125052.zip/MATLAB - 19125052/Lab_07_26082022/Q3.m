function check_amstrong(num)
  if isnumeric(num)
    num_ams = num2str(num);
  else
    error('Input shoud be numberic')
  end
  amst_num = 0;
  for i = 1 : length(num_ams)
    amst_num = amst_num + str2double(num_ams(i)) ^ length(num_ams);
  end
  if amst_num == num
    disp(['Given Number ' num_ams ' is Amstrong_Number']);
  else
  disp(['Given Number ' num_ams ' is NOT a Amstrong_Number']);
end